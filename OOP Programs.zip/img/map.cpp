#include<iostream>
#include<map>
#include<string>
#include<cstdlib>
using namespace std;
int main()
{
    map<int,string>mp;
    map<int,string>::iterator itr;
    int choice,tel_no,n;
    string name,new_name;
    while(true)
    {
        cout<<"MAP IMPLEMENTATION USING STL\n";
        cout<<"1.Insert Element\n";
        cout<<"2.Display Element\n";
        cout<<"3.Search Element\n";
        cout<<"4.Delete Element\n";
        cout<<"5.Update Element\n";
        cout<<"6.Exit\n\n";
        cout<<"Enter Your Choice ";
        cin>>choice;
        switch (choice)
        {
        case 1: cout<<"Enter the key :";
                cin>>tel_no;
                cout<<"Enter the Value :";
                cin>>name;
                mp.insert(pair<int,string>(tel_no,name));
                break;
        case 2: for(itr=mp.begin();itr!=mp.end();++itr)
                {
                    cout<<"Key : "<<itr->first<<" Value :"<<itr->second<<endl;
                }
                break;
        case 3: cout<<"Enter the key to search element\n";
                cin>>tel_no;
                cout<<mp.find(tel_no)->second<<endl;
                break;
        case 4: cout<<"Enter the key that you  want to delete\n";
                cin>>tel_no;
                mp.erase(tel_no);
                break;
        case 5: cout<<"Enter key whose value you want to update\n";
                cin>>tel_no;
                itr=mp.find(tel_no);
                if(itr!=mp.end())
                {
                    cout<<"Enter new value : \n";
                    cin>>new_name;
                    itr->second=new_name;
                    cout<<"Map after updation\n";
                    for(itr=mp.begin();itr!=mp.end();++itr)
                    {
                        cout<<"Key : "<<itr->first<<" Value : "<<itr->second<<endl;
                    }
                } 
                break;
        case 6: exit(0);
                break;
        default: cout<<"Invalid Choice";
            break;
        }
    }
}