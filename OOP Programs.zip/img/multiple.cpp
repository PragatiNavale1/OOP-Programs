#include<iostream>
using namespace std;
class BasicInfo
{
    public:
    char name[20],gender[10];
    long mobile;
    void getinfo()
    {
        cout<<"***Enter Details of Employee***"<<endl;
        cout<<"Enter name of employee : ";
        cin>>name;
        cout<<endl<<"Enter Gender of employee : ";
        cin>>gender;
        cout<<endl<<"Enter Mobile Number of employee : ";
        cin>>mobile;
    }
};
class DeptInfo
{
    public:
    char deptname[20];
    int empid;
    void getinfo()
    {
        cout<<"Enter Department name of employee : ";
        cin>>deptname;
        cout<<endl<<"Enter Employee Id : ";
        cin>>empid;
    }
};
class Employee:public BasicInfo,public DeptInfo
{
    public:
    void display()
    {
        cout<<"***EMPLOYEE BASIC DETAILS***"<<endl;
        cout<<"Employee Name : "<<name<<endl;
        cout<<"Employee Gender : "<<gender<<endl;
        cout<<"Employee Mobile Number : "<<mobile<<endl;
        cout<<"***EMPLOYEE DEPARTMENT DETAILS***"<<endl;
        cout<<"Employee Department : "<<deptname<<endl;
        cout<<"Employee Id : "<<empid<<endl;
    }
};
int main()
{
    Employee e;
    e.BasicInfo::getinfo();
    e.DeptInfo::getinfo();
    e.display();
    return 0;
}