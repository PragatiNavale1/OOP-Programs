#include <iostream>
#include <string>

using namespace std;

const int MAX_ENTRIES = 100; // Maximum number of entries

class Student {
protected:
    string name;
    int rollNumber;
    string subject;

public:
    virtual void readData() {
        cout << "Enter Name: ";
        cin >> name;

        cout << "Enter Roll Number: ";
        cin >> rollNumber;

        cout << "Enter Subject: ";
        cin >> subject;
    }

    virtual void displayData() const {
        cout << "Name: " << name << endl;
        cout << "Roll Number: " << rollNumber << endl;
        cout << "Subject: " << subject << endl;
    }

    virtual int getRollNumber() const {
        return rollNumber;
    }
};

class Result : public Student {
private:
    int subjectCode;
    float internalAssessment;
    float universityExamMarks;

public:
    void readData() override {
        Student::readData();

        cout << "Enter Subject Code: ";
        cin >> subjectCode;

        cout << "Enter Internal Assessment Marks: ";
        cin >> internalAssessment;

        cout << "Enter University Exam Marks: ";
        cin >> universityExamMarks;
    }

    void displayData() const override {
        Student::displayData();
        cout << "Subject Code: " << subjectCode << endl;
        cout << "Internal Assessment Marks: " << internalAssessment << endl;
        cout << "University Exam Marks: " << universityExamMarks << endl;
    }
};

class StudentDatabase {
private:
    Result database[MAX_ENTRIES]; // Array of Result objects
    int numEntries; // Number of entries in the database

public:
void buildMasterTable() {
        cout << "Enter the number of entries: ";
        cin >> numEntries;

        for (int i = 0; i < numEntries; ++i) {
            cout << "\nEnter details for Student " << i + 1 << ":\n";
            database[i].readData();
        }
    }

void listTable() const {
        cout << "\nListing the Student Database:\n";
        for (int i = 0; i < numEntries; ++i) {
            database[i].displayData();
            cout << "---------------------------------\n";
        }
    }

void insertNewEntry() {
        if (numEntries < MAX_ENTRIES) {
            cout << "\nEnter details for the new Student:\n";
            database[numEntries].readData();
            ++numEntries;
            cout << "New entry added successfully!\n";
        } else {
            cout << "Cannot add more entries. Database is full.\n";
        }
    }

void deleteOldEntry() {
        int rollToDelete;
        cout << "Enter the roll number to delete: ";
        cin >> rollToDelete;

     bool found = false;
     for (int i = 0; i < numEntries; ++i) {
     if (database[i].getRollNumber() == rollToDelete) {
        found = true;

        // Shift elements to overwrite the entry to be deleted
        for (int j = i; j < numEntries - 1; ++j) {
            database[j] = database[j + 1];
        }

        // Decrement the number of entries
        --numEntries;

        cout << "Entry with roll number " << rollToDelete << " deleted successfully!\n";

        // Break out of the loop once the entry is found and deleted
        break;
    }
  }

     if (!found) {
    cout << "Entry with roll number " << rollToDelete << " not found.\n";
   }
}

void editEntry() {
        int rollToEdit;
        cout << "Enter the roll number to edit: ";
        cin >> rollToEdit;
        bool found = false;
        for (int i = 0; i < numEntries; ++i) {
        if (database[i].getRollNumber() == rollToEdit) {
        found = true;

        cout << "Enter new details for Student with roll number " << rollToEdit << ":\n";
        database[i].readData();
        cout << "Entry with roll number " << rollToEdit << " edited successfully!\n";

        // Break out of the loop once the entry is found and edited
        break;
    }
  }
  if (!found) {
    cout << "Entry with roll number " << rollToEdit << " not found.\n";
    }
}

void searchRecord() const {
        int rollToSearch;
        cout << "Enter the roll number to search: ";
        cin >> rollToSearch;

        bool found = false;
        for (int i = 0; i < numEntries; ++i) {
        if (database[i].getRollNumber() == rollToSearch) {
        found = true;

        cout << "Record found for Student with roll number " << rollToSearch << ":\n";
        database[i].displayData();

        // Break out of the loop once the record is found and displayed
        break;
     }
    }

    if (!found) {
    cout << "Record not found for Student with roll number " << rollToSearch << ".\n";
    }
}
};

int main() {
    StudentDatabase studentDB;

    int choice;

    do {
        cout << "\n************ Student Database Menu ************\n";
        cout << "1. Build Master Table\n";
        cout << "2. List Table\n";
        cout << "3. Insert New Entry\n";
        cout << "4. Delete Old Entry\n";
        cout << "5. Edit Entry\n";
        cout << "6. Search for a Record\n";
        cout << "0. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                studentDB.buildMasterTable();
                break;

            case 2:
                studentDB.listTable();
                break;

            case 3:
                studentDB.insertNewEntry();
                break;

            case 4:
                studentDB.deleteOldEntry();
                break;

            case 5:
                studentDB.editEntry();
                break;

            case 6:
                studentDB.searchRecord();
                break;

            case 0:
                cout << "Exiting the program.\n";
                break;

            default:
                cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 0);

    return 0;
}