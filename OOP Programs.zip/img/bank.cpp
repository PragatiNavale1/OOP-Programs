#include<iostream>
using namespace std;
class Bank
{
    char name[20],account_type[10];
    long account_no,bal,withdraw,deposite;
    public:
    void account_details()
    {
        cout<<"****ENTER YOUR DEATILS****\n";
        cout<<"Enter Your Name : ";
        cin>>name;
        cout<<"Enter Account Type : ";
        cin>>account_type;
        cout<<"Enter Account Number : ";
        cin>>account_no;
        cout<<"Enter Opening Balance : ";
        cin>>bal;
    }
    void deposite_amount()
    {
        deposite=0;
        cout<<"Enter Amount of deposite : ";
        cin>>deposite;
        deposite=bal+deposite;
        bal=deposite;
        cout<<"Now Your Bank Balance is : "<<bal;
    }
    void withdraw_amount()
    {
        cout<<"Your Current Bank Balance is : "<<bal;
        cout<<"\nEnter Amount to withdraw : ";
        cin>>withdraw;
        if(withdraw>bal){
            cout<<"Less Balance....";
        }
        else{
        bal=bal-withdraw;
        cout<<"Now Your Bank Balance is : "<<bal;
        }
    }
    void display_details()
    {
        cout<<"Name of Account Holder : "<<name;
        cout<<"\nAccount Type : "<<account_type;
        cout<<"\nAccount Number : "<<account_no;
        cout<<"\nAccount Balance : "<<bal;
    }
};
int main()
{
    Bank b;
    int i=1;
    while (i<=5)
    {
        cout<<"\n\n\n1.Enter Your Details\n";
        cout<<"2.Deposite\n";
        cout<<"3.Withdraw\n";
        cout<<"4.Display Details\n";
        cout<<"5.Exit\n";
        int choice;
        cout<<"Enter Your Choice : ";
        cin>>choice;
        switch (choice)
        {
        case 1: b.account_details();
                break;
        case 2: b.deposite_amount();
                break;
        case 3: b.withdraw_amount();
                break;
        case 4: b.display_details();
                break;
        case 5: exit(0);
                break;
        }
        i++;
    };
return 0;
}