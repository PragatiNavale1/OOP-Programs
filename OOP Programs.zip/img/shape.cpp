#include<iostream>
using namespace std;
class SHAPE
{
    public:
    double side1,side2;
    public:
    void getdata()
    {
        cout<<"Enter Value of side 1 : ";
        cin>>side1;
        cout<<"Enter Value of side 2 : ";
        cin>>side2;
    }
    virtual void display_area()=0;
};
class Triangle:public SHAPE
{
    public:
    void display_area()
    {
        double area=0.5*side1*side2;
        cout<<"Area of Triangle is : "<<area;
    }
};
class Rectangle:public SHAPE
{
    public:
    void display_area()
    {
        double area=side1*side2;
        cout<<"Area of Rectangle is : "<<area;
    }
};
int main()
{
    // int choice;
    // for(int i=0;i<2;i++){
    //     cout<<"\nChoose a Shape:\n 1.Triangle\n2.Rectangle\n";
    //     cin>>choice;
    //     if (choice==1)
    //     {
    //         Triangle t;
    //         SHAPE *s=&t;
    //         s->getdata();
    //         s->display_area();
    //     }
    //     else if(choice==2)
    //     {
    //         Rectangle r;
    //         SHAPE *s=&r;
    //         s->getdata();
    //         s->display_area();
    //     }
    //     else
    //     {
    //         cout<<"Invalid Choice";
    //     }
    //}
            cout<<"*****TRIANGLE*****\n";
            Triangle t;
            SHAPE *s=&t;
            s->getdata();
            s->display_area();
            cout<<"\n*****RECTANGLE*****\n";
            Rectangle r;
            SHAPE *s1=&r;
            s1->getdata();
            s1->display_area();
return 0;
}
