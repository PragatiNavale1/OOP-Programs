#include<iostream>
using namespace std;
class matrix
{
    public:
    int m1[10][10],m2[10][10],m3[10][10];
    int r1,c1,r2,c2;
    void read()
    {
        cout<<"Enter Number of rows of matrix 1 :"<<endl;
        cin>>r1;
        cout<<"Enter Number of columns of matrix 1 :"<<endl;
        cin>>c1;
        cout<<"Enter Number of rows of matrix 2 :"<<endl;
        cin>>r2;
        cout<<"Enter Number of columns of matrix 2 :"<<endl;
        cin>>c2;
        try
        {
            if(r1>10 || r2>10 || c1>10 || c2>10)
            {
                throw 1;
            }
            else
            {
               cout<<"Enter Array Elements in Matrix 1"<<endl;
               for(int i=0;i<r1;i++)
               {
                    for(int j=0;j<c1;j++)
                    {
                        cin>>m1[i][j];
                    }
               }
               cout<<"Enter Array Elements in Matrix 2"<<endl;
               for(int i=0;i<r2;i++)
               {
                    for(int j=0;j<c2;j++)
                    {
                        cin>>m2[i][j];
                    }
               }
               if(r1==r2 && c1==c2)
                    {
                        cout<<"ADDITION OF MATRIX IS"<<endl;
                        for(int i=0;i<r1;i++)
                        {
                                for(int j=0;j<c1;j++)
                                {
                                    cout<<m1[i][j]+m2[i][j]<<" ";
                                }
                                cout<<endl;
                        }
                        cout<<"SUBSTRACTION OF MATRIX IS"<<endl;
                        for(int i=0;i<r1;i++)
                        {
                                for(int j=0;j<c1;j++)
                                {
                                    cout<<m1[i][j]-m2[i][j]<<" ";
                                }
                                cout<<endl;
                        }
                    }
                else
                {
                    try
                    {
                         throw 2;
                    }
                    catch(int)
                    {
                            cout<<"Due to the mismatch of rows and cols of m1 and rows and cols of m2 respectively addition and substraction cannot be performed ";
                    }
                }
                if(c1==r2)
                {
                        cout<<"MULYIPLICATION OF MATRIX IS"<<endl;
                        for(int i=0;i<r1;i++)
                        {
                                for(int j=0;j<c2;j++)
                                {
                                    m3[i][j]=0;
                                        for(int k=0;k<r2;k++)
                                        {
                                            m3[i][j]+=m1[i][k]*m2[k][j];
                                        }
                                }
                        }
                         for(int i=0;i<r1;i++)
                        {
                                for(int j=0;j<c1;j++)
                                {
                                    cout<<m3[i][j]<<" ";
                                }
                                cout<<endl;
                        }
                }
                else
                {
                     try
                    {
                         throw 3;
                    }
                    catch(int)
                    {
                            cout<<"Due to the mismatch of cols of m1 and rows of m2 Multiplication can not be performed";
                    }
                }
            }
        }
        catch(int)
        {
            cout<<"Subscript Invalid";
        }
    }  
};
int main()
{
    matrix m;
    m.read();
}