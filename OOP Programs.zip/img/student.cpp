#include<iostream>
#include<cstring>
using namespace std;
class student
{
    public:
    string name;
    float total,ave,marks[5];
    void getdata()
    {
        cout<<"Enter Name of the Student : ";
        cin>>name;
        cout<<endl<<"Enter Marks : ";
        for(int i=1;i<=5;i++)
        {
            cout<<endl<<"Enter Marks of Subject "<<i<<" : ";
            cin>>marks[i];
        }

    }
    void display()
    {
        total=0;
        for(int i=1;i<=5;i++)
        {
            total+=marks[i];
        }
        ave=total/5;
        cout<<"Name of the Student : "<<name<<endl;
        cout<<"Total Marks is : "<<total<<endl;
        cout<<"Percentage is : "<<ave<<endl;
    }
};
int main()
{
    student s;
    s.getdata();
    s.display();
    return 0;
}